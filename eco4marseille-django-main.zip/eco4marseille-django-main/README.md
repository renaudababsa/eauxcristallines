# README

1- clone the repository

2- run docker-compose --build

3- enjoy

4- Do not modify doker-compose.yaml. EVER